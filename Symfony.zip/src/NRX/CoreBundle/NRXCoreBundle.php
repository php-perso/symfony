<?php

namespace NRX\CoreBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class NRXCoreBundle extends Bundle
{
}
