<?php

namespace NRX\PlatformBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class NRXPlatformBundle extends Bundle
{
}
